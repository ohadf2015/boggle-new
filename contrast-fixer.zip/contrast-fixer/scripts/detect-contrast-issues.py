#!/usr/bin/env python3
"""
Contrast Issue Detector for Tailwind CSS + React/Next.js Projects

Detects potential contrast issues:
- Dark text on dark backgrounds
- Light text on light backgrounds
- Missing foreground colors on colored backgrounds

Usage:
    python detect-contrast-issues.py [--path <directory>] [--fix] [--json]

Options:
    --path      Directory to scan (default: current directory)
    --fix       Suggest fixes inline
    --json      Output results as JSON
    --verbose   Show all scanned files
"""

import os
import re
import sys
import json
import argparse
from pathlib import Path
from dataclasses import dataclass, asdict
from typing import List, Dict, Tuple, Optional, Set

# Color classifications based on Tailwind and common patterns
DARK_COLORS = {
    # Standard Tailwind darks
    'black', 'gray-900', 'gray-800', 'gray-700', 'slate-900', 'slate-800', 'slate-700',
    'zinc-900', 'zinc-800', 'zinc-700', 'neutral-900', 'neutral-800', 'neutral-700',
    'stone-900', 'stone-800', 'stone-700',
    # Neo-Brutalist theme darks
    'neo-black', 'neo-navy', 'neo-navy-light', 'neo-gray',
    # Generic dark patterns
    'dark', 'navy', 'indigo-900', 'indigo-800', 'purple-900', 'purple-800',
    'blue-900', 'blue-800', 'green-900', 'green-800', 'red-900', 'red-800',
}

LIGHT_COLORS = {
    # Standard Tailwind lights
    'white', 'gray-100', 'gray-50', 'slate-100', 'slate-50',
    'zinc-100', 'zinc-50', 'neutral-100', 'neutral-50',
    'stone-100', 'stone-50',
    # Neo-Brutalist theme lights
    'neo-white', 'neo-cream', 'neo-yellow', 'neo-lime', 'neo-cyan',
    # Generic light patterns
    'light', 'cream', 'ivory', 'beige',
}

# Medium/vibrant colors that need specific foreground handling
VIBRANT_COLORS = {
    'neo-pink', 'neo-purple', 'neo-orange', 'neo-red',
    'pink', 'purple', 'orange', 'red', 'blue', 'green', 'indigo', 'violet',
    'amber', 'yellow', 'lime', 'emerald', 'teal', 'cyan', 'sky', 'fuchsia', 'rose',
}

# Mapping of background colors to recommended foreground colors
FOREGROUND_RECOMMENDATIONS = {
    # Dark backgrounds -> light text
    'bg-neo-navy': 'text-neo-white or text-neo-cream',
    'bg-neo-gray': 'text-neo-white or text-neo-cream',
    'bg-neo-black': 'text-neo-white',
    'bg-slate-900': 'text-white or text-slate-100',
    'bg-gray-900': 'text-white or text-gray-100',
    'bg-black': 'text-white',
    # Light backgrounds -> dark text
    'bg-neo-cream': 'text-neo-black',
    'bg-neo-yellow': 'text-neo-black',
    'bg-white': 'text-black or text-gray-900',
    'bg-neo-lime': 'text-neo-black',
    # Vibrant backgrounds
    'bg-neo-pink': 'text-neo-white or text-neo-black',
    'bg-neo-purple': 'text-neo-white',
    'bg-neo-orange': 'text-neo-black',
    'bg-neo-cyan': 'text-neo-black',
}


@dataclass
class ContrastIssue:
    """Represents a detected contrast issue"""
    file: str
    line: int
    column: int
    issue_type: str  # 'dark-on-dark', 'light-on-light', 'missing-foreground', 'potential-issue'
    severity: str    # 'error', 'warning', 'info'
    context: str     # The line content
    bg_color: Optional[str]
    text_color: Optional[str]
    suggestion: str
    element_snippet: str


def is_dark_color(color: str) -> bool:
    """Check if a color is classified as dark"""
    color_lower = color.lower()
    for dark in DARK_COLORS:
        if dark in color_lower:
            return True
    # Check for opacity variants that make colors effectively dark
    if re.search(r'/(90|95)\]?$', color):
        return True
    return False


def is_light_color(color: str) -> bool:
    """Check if a color is classified as light"""
    color_lower = color.lower()
    for light in LIGHT_COLORS:
        if light in color_lower:
            return True
    # Check for opacity variants that make colors effectively light
    if re.search(r'/(5|10)\]?$', color):
        return True
    return False


def extract_color_from_class(class_name: str) -> Optional[str]:
    """Extract the color portion from a Tailwind class"""
    # Match patterns like: text-neo-black, bg-slate-900, text-white/50
    patterns = [
        r'^(?:text|bg|border|ring)-(.+?)(?:/\d+)?$',
        r'^(?:text|bg|border|ring)-\[(.+?)\]$',
    ]
    for pattern in patterns:
        match = re.match(pattern, class_name)
        if match:
            return match.group(1)
    return None


def find_classes_in_element(element_str: str) -> Tuple[List[str], List[str], List[str]]:
    """Extract background, text, and other color classes from an element string"""
    # Find className or class attribute
    class_patterns = [
        r'className\s*=\s*[`"\']([^`"\']+)[`"\']',
        r'className\s*=\s*\{[`"\']([^`"\']+)[`"\']\}',
        r'className\s*=\s*\{\s*`([^`]+)`\s*\}',
        r'class\s*=\s*["\']([^"\']+)["\']',
    ]

    all_classes = []
    for pattern in class_patterns:
        matches = re.findall(pattern, element_str, re.DOTALL)
        for match in matches:
            # Handle template literals
            clean_match = re.sub(r'\$\{[^}]+\}', '', match)
            all_classes.extend(clean_match.split())

    bg_classes = [c for c in all_classes if c.startswith('bg-')]
    text_classes = [c for c in all_classes if c.startswith('text-') and not c.startswith('text-[') or c.startswith('text-neo-')]
    other_classes = [c for c in all_classes if c not in bg_classes and c not in text_classes]

    return bg_classes, text_classes, other_classes


def analyze_element(element_str: str, file_path: str, line_num: int) -> List[ContrastIssue]:
    """Analyze a single element for contrast issues"""
    issues = []
    bg_classes, text_classes, _ = find_classes_in_element(element_str)

    # Skip if no styling found
    if not bg_classes and not text_classes:
        return issues

    # Get primary colors
    bg_color = None
    text_color = None

    for bg_class in bg_classes:
        color = extract_color_from_class(bg_class)
        if color:
            bg_color = color
            break

    for text_class in text_classes:
        color = extract_color_from_class(text_class)
        if color:
            text_color = color
            break

    # Check for dark-on-dark
    if bg_color and text_color:
        if is_dark_color(bg_color) and is_dark_color(text_color):
            issues.append(ContrastIssue(
                file=file_path,
                line=line_num,
                column=0,
                issue_type='dark-on-dark',
                severity='error',
                context=element_str[:200],
                bg_color=bg_color,
                text_color=text_color,
                suggestion=f"Use light text (text-neo-white, text-neo-cream, text-white) instead of text-{text_color}",
                element_snippet=element_str[:100]
            ))

        # Check for light-on-light
        elif is_light_color(bg_color) and is_light_color(text_color):
            issues.append(ContrastIssue(
                file=file_path,
                line=line_num,
                column=0,
                issue_type='light-on-light',
                severity='error',
                context=element_str[:200],
                bg_color=bg_color,
                text_color=text_color,
                suggestion=f"Use dark text (text-neo-black, text-black, text-gray-900) instead of text-{text_color}",
                element_snippet=element_str[:100]
            ))

    # Check for missing foreground on colored backgrounds
    if bg_color and not text_color:
        bg_class = f"bg-{bg_color}"
        if bg_class in FOREGROUND_RECOMMENDATIONS:
            issues.append(ContrastIssue(
                file=file_path,
                line=line_num,
                column=0,
                issue_type='missing-foreground',
                severity='warning',
                context=element_str[:200],
                bg_color=bg_color,
                text_color=None,
                suggestion=f"Add explicit text color: {FOREGROUND_RECOMMENDATIONS[bg_class]}",
                element_snippet=element_str[:100]
            ))
        elif is_dark_color(bg_color):
            issues.append(ContrastIssue(
                file=file_path,
                line=line_num,
                column=0,
                issue_type='missing-foreground',
                severity='info',
                context=element_str[:200],
                bg_color=bg_color,
                text_color=None,
                suggestion="Consider adding explicit light text color for dark background",
                element_snippet=element_str[:100]
            ))

    return issues


def scan_file(file_path: str) -> List[ContrastIssue]:
    """Scan a single file for contrast issues"""
    issues = []

    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
            lines = content.split('\n')
    except Exception as e:
        print(f"Error reading {file_path}: {e}", file=sys.stderr)
        return issues

    # Find JSX elements with className
    # Match opening tags with class attributes
    element_pattern = r'<(\w+)[^>]*(?:className|class)\s*=\s*[{"\'][^>]*>'

    for line_num, line in enumerate(lines, 1):
        matches = re.finditer(element_pattern, line)
        for match in matches:
            element_str = match.group(0)
            issues.extend(analyze_element(element_str, file_path, line_num))

    # Also check for multi-line elements
    multiline_pattern = r'<(\w+)\s+[^>]*(?:className|class)\s*=\s*\{?[`"\'][^}]*?[`"\']\}?[^>]*>'
    for match in re.finditer(multiline_pattern, content, re.DOTALL):
        element_str = match.group(0)
        # Find line number
        line_num = content[:match.start()].count('\n') + 1
        issues.extend(analyze_element(element_str, file_path, line_num))

    return issues


def scan_directory(directory: str, extensions: Set[str] = None) -> List[ContrastIssue]:
    """Scan a directory recursively for contrast issues"""
    if extensions is None:
        extensions = {'.tsx', '.jsx', '.ts', '.js'}

    all_issues = []
    directory = Path(directory)

    # Skip node_modules and other common directories
    skip_dirs = {'node_modules', '.git', '.next', 'dist', 'build', '.claude'}

    for file_path in directory.rglob('*'):
        if file_path.is_file() and file_path.suffix in extensions:
            # Check if we should skip this path
            if any(skip_dir in file_path.parts for skip_dir in skip_dirs):
                continue

            issues = scan_file(str(file_path))
            all_issues.extend(issues)

    return all_issues


def format_issue(issue: ContrastIssue, show_fix: bool = False) -> str:
    """Format a single issue for console output"""
    severity_colors = {
        'error': '\033[91m',    # Red
        'warning': '\033[93m',  # Yellow
        'info': '\033[94m',     # Blue
    }
    reset = '\033[0m'
    bold = '\033[1m'

    color = severity_colors.get(issue.severity, '')

    output = []
    output.append(f"\n{color}{bold}[{issue.severity.upper()}]{reset} {issue.file}:{issue.line}")
    output.append(f"  Type: {issue.issue_type}")
    if issue.bg_color:
        output.append(f"  Background: {issue.bg_color}")
    if issue.text_color:
        output.append(f"  Text: {issue.text_color}")
    output.append(f"  {color}Suggestion: {issue.suggestion}{reset}")

    if show_fix:
        output.append(f"  Context: {issue.element_snippet}...")

    return '\n'.join(output)


def main():
    parser = argparse.ArgumentParser(
        description='Detect contrast issues in React/Next.js Tailwind projects'
    )
    parser.add_argument('--path', default='.', help='Directory to scan')
    parser.add_argument('--fix', action='store_true', help='Show fix suggestions inline')
    parser.add_argument('--json', action='store_true', help='Output as JSON')
    parser.add_argument('--verbose', action='store_true', help='Show all scanned files')
    parser.add_argument('--severity', choices=['error', 'warning', 'info'],
                       help='Minimum severity to report')

    args = parser.parse_args()

    # Scan the directory
    issues = scan_directory(args.path)

    # Filter by severity
    if args.severity:
        severity_order = {'error': 0, 'warning': 1, 'info': 2}
        min_severity = severity_order[args.severity]
        issues = [i for i in issues if severity_order[i.severity] <= min_severity]

    # Sort issues by severity and file
    severity_order = {'error': 0, 'warning': 1, 'info': 2}
    issues.sort(key=lambda x: (severity_order[x.severity], x.file, x.line))

    # Output results
    if args.json:
        print(json.dumps([asdict(i) for i in issues], indent=2))
    else:
        if not issues:
            print("\n\033[92m✓ No contrast issues detected!\033[0m")
            return 0

        # Group by file
        by_file: Dict[str, List[ContrastIssue]] = {}
        for issue in issues:
            if issue.file not in by_file:
                by_file[issue.file] = []
            by_file[issue.file].append(issue)

        # Summary
        errors = sum(1 for i in issues if i.severity == 'error')
        warnings = sum(1 for i in issues if i.severity == 'warning')
        infos = sum(1 for i in issues if i.severity == 'info')

        print(f"\n{'='*60}")
        print(f"CONTRAST ISSUE REPORT")
        print(f"{'='*60}")
        print(f"Scanned: {args.path}")
        print(f"Issues found: {len(issues)} ({errors} errors, {warnings} warnings, {infos} info)")
        print(f"{'='*60}")

        for file_path, file_issues in by_file.items():
            print(f"\n\033[1m{file_path}\033[0m ({len(file_issues)} issues)")
            for issue in file_issues:
                print(format_issue(issue, args.fix))

        print(f"\n{'='*60}")
        print("Fix priority:")
        print("  1. \033[91mERROR\033[0m - Dark-on-dark or light-on-light text (unreadable)")
        print("  2. \033[93mWARNING\033[0m - Missing explicit foreground color")
        print("  3. \033[94mINFO\033[0m - Potential issues to review")
        print(f"{'='*60}\n")

        return 1 if errors > 0 else 0

    return 0


if __name__ == '__main__':
    sys.exit(main())
