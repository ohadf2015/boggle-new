---
name: commit-push
description: This skill should be used when the user wants to verify all code quality checks (translations, linting, type checking, tests), fix any issues found, and then commit and push changes to the remote repository. Use when the user requests to commit and push code after completing features or bug fixes. Executes verification steps in parallel for maximum speed.
---

# Commit Push

## Overview

This skill provides a comprehensive pre-commit workflow that ensures code quality before pushing to the remote repository. It verifies translations are complete, fixes linting issues, resolves type errors, ensures tests pass, and then commits and pushes the changes with a meaningful commit message. **Uses parallel agents for blazing fast execution.**

## When to Use This Skill

Use this skill when:
- User explicitly requests to commit and push changes
- User asks to "verify and push" or "check and commit"
- User wants to ensure all quality checks pass before pushing
- After completing a feature or bug fix that needs to be committed

## Workflow Process

The workflow uses parallel execution to maximize speed while maintaining thorough quality checks.

### Phase 1: Parallel Verification (Steps 1-4)

**CRITICAL: Run all four verification steps in parallel using multiple Task agents in a SINGLE message.**

Launch four agents simultaneously by sending ONE message with FOUR Task tool calls:

1. **Translation Agent**: Verify translations are complete
2. **Linting Agent**: Run ESLint and fix issues
3. **Type Checking Agent**: Run TypeScript type checks and fix errors
4. **Test Agent**: Run test suite and fix failures

**Instructions for each parallel agent:**

#### Agent 1: Translation Verification
- Run the /complete-translation skill
- If issues found, add missing translation keys and re-verify
- Report: translations complete or list of issues fixed

#### Agent 2: ESLint Verification
- Run: `npm run lint`
- If issues found, run: `npm run lint -- --fix`
- For manual fixes: read files, apply corrections per CLAUDE.md
- Re-run to verify
- Report: linting passed or list of issues fixed

#### Agent 3: Type Checking Verification
- Run: `npx tsc --noEmit`
- If errors found: read files, fix types (no `any` types)
- Re-run to verify
- Report: type checking passed or list of errors fixed

#### Agent 4: Test Verification
- Run: `npm run test`
- If failures found: analyze each test, fix root cause
- Prioritize fixing bugs over changing tests
- Re-run to verify
- Report: tests passed or list of fixes applied

**Wait for all four agents to complete before proceeding to Phase 2.**

### Phase 2: Build Verification (Step 5)

After all Phase 1 agents complete successfully, verify the build.

```bash
npm run build
```

If build fails:
- Review build errors
- Fix compilation or bundling issues
- Re-run `npm run build` to verify
- Do NOT proceed until build succeeds

### Phase 3: Commit and Push (Steps 6-8)

After build succeeds, proceed with committing and pushing.

#### Step 6: Generate Commit Message

Create a meaningful commit message following conventions:

**Format:**
- Use conventional commit style: `feat:`, `fix:`, `refactor:`, `test:`, `docs:`
- First line: Brief summary (50-72 characters)
- Body: Detailed explanation if changes are complex
- Include: `Co-Authored-By: Claude Sonnet 4.5 <noreply@anthropic.com>`

**Examples:**

```
feat: Add daily buzz challenge generation with automated image processing

Implemented automated daily buzz challenge system with:
- SerpAPI integration for trending topics
- Imagen AI for challenge image generation
- Background job scheduling via cron
- Admin panel for manual generation

Co-Authored-By: Claude Sonnet 4.5 <noreply@anthropic.com>
```

```
fix: Resolve type errors in buzz challenge components

Co-Authored-By: Claude Sonnet 4.5 <noreply@anthropic.com>
```

#### Step 7: Commit Changes

Stage and commit all changes:

```bash
git add .
git commit -m "$(cat <<'EOF'
[Your commit message here]

Co-Authored-By: Claude Sonnet 4.5 <noreply@anthropic.com>
EOF
)"
```

**Important:**
- Use heredoc for multi-line commit messages
- Review `git status` before committing
- Ensure no sensitive files are being committed

#### Step 8: Push to Remote

```bash
git push
```

If push fails:
- Check upstream: `git push -u origin [branch-name]`
- Pull and rebase if needed: `git pull --rebase origin [branch-name]`
- Resolve merge conflicts if they occur
- Re-run `git push`

## Parallel Execution Guidelines

**Critical for speed:**
- Always run Phase 1 agents in parallel - send ONE message with FOUR Task tool calls
- Do not run sequentially unless one depends on another's output
- Wait for all Phase 1 agents to complete before Phase 2
- Use `subagent_type: Bash` for command execution agents

## Error Handling Principles

Throughout the workflow:
- **Never skip steps** - Each verification is critical
- **Fix root causes** - No superficial patches
- **Verify fixes work** - Re-run checks after changes
- **Document fixes** - Report what was found and resolved
- **Graceful degradation** - If stuck, explain and ask for guidance

## Success Criteria

The workflow is complete when:
- ✅ All translations complete
- ✅ ESLint passes (zero errors/warnings)
- ✅ TypeScript type checking passes (zero errors)
- ✅ All tests pass
- ✅ Build succeeds
- ✅ Changes committed with meaningful message
- ✅ Changes pushed to remote

## Final Report

After successful completion, provide:

```
✅ Commit and Push Complete

Checks performed:
- Translations: [Complete/Fixed X issues]
- Linting: [Passed/Fixed X issues]
- Type checking: [Passed/Fixed X errors]
- Tests: [Passed/Fixed X failures]
- Build: [Passed]

Commit: [commit hash]
Message: [first line of commit message]
Pushed to: [branch name]
```
